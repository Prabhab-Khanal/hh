# Core PHP MVC Mini Apps (Composer PSR-4, Docker: Nginx + PHP-FPM)

Apps:
- todo-app
- contact-app
- csv-app
- login-app (simple credential check; no sessions)

Per app run:
```bash
cd todo-app
docker compose run --rm php composer install
docker compose up --build
```

DB schema: `sql/schema_all.sql` (run once).
