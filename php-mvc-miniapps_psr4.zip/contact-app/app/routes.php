<?php
$ctl = new \App\Controllers\ContactController();
$this->router()->get('/', fn() => $ctl->form());
$this->router()->post('/send', fn() => $ctl->send());
$this->router()->get('/admin', fn() => $ctl->admin());
