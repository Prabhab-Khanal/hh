<h1>admin</h1>
<p><a href="/">back</a></p>
<?php foreach ($items as $c): ?>
  <hr>
  <p>#<?= (int)$c['id'] ?> <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['email']) ?>)</p>
  <p><?= nl2br(htmlspecialchars($c['message'])) ?></p>
  <small><?= htmlspecialchars($c['created_at']) ?></small>
<?php endforeach; ?>
