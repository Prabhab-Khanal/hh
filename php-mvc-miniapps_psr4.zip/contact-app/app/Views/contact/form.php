<h1>contact</h1>
<form method="post" action="/send">
  <p><input name="name" placeholder="name"></p>
  <p><input name="email" placeholder="email"></p>
  <p><textarea name="message" rows="5" cols="30" placeholder="message"></textarea></p>
  <button type="submit">send</button>
</form>
<p><a href="/admin">admin</a></p>
