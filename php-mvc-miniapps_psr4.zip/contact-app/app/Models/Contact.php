<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Contact
{
    public function create(string $n, string $e, string $m): void
    {
        $st = Database::pdo()->prepare("INSERT INTO contacts (name,email,message) VALUES (:n,:e,:m)");
        $st->execute(['n'=>$n,'e'=>$e,'m'=>$m]);
    }

    public function all(): array
    {
        return Database::pdo()->query("SELECT id,name,email,message,created_at FROM contacts ORDER BY id DESC")->fetchAll();
    }
}
