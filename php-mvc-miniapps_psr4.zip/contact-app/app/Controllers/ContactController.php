<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Contact;

final class ContactController extends Controller
{
    public function form(): void { $this->view('contact/form', ['title' => 'contact']); }

    public function send(): void
    {
        $n = trim((string)($_POST['name'] ?? ''));
        $e = trim((string)($_POST['email'] ?? ''));
        $m = trim((string)($_POST['message'] ?? ''));
        if ($n && $e && $m && filter_var($e, FILTER_VALIDATE_EMAIL)) {
            (new Contact())->create($n, $e, $m);
            $this->redirect('/admin');
            return;
        }
        echo "<p>bad input</p><a href='/'>back</a>";
    }

    public function admin(): void
    {
        $items = (new Contact())->all();
        $this->view('contact/admin', ['title' => 'admin', 'items' => $items]);
    }
}
