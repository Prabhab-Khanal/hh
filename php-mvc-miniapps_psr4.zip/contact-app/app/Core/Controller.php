<?php
declare(strict_types=1);

namespace App\Core;

abstract class Controller
{
    protected function view(string $view, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        $base = __DIR__ . '/../Views/';
        $file = $base . $view . '.php';
        if (!file_exists($file)) throw new \RuntimeException("View missing: " . $file);
        require $base . 'layout/header.php';
        require $file;
        require $base . 'layout/footer.php';
    }

    protected function redirect(string $path): void
    {
        header('Location: ' . $path);
        exit;
    }
}
