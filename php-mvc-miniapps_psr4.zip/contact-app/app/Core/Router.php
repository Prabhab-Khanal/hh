<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    private array $routes = ['GET' => [], 'POST' => []];

    public function get(string $path, callable $handler): void
    {
        $this->routes['GET'][$this->norm($path)] = $handler;
    }

    public function post(string $path, callable $handler): void
    {
        $this->routes['POST'][$this->norm($path)] = $handler;
    }

    public function dispatch(string $method, string $path): void
    {
        $method = strtoupper($method);
        $p = $this->norm(parse_url($path, PHP_URL_PATH) ?: '/');
        $h = $this->routes[$method][$p] ?? null;
        if (!$h) {
            http_response_code(404);
            echo "<h1>404</h1><p>not found</p>";
            return;
        }
        $h();
    }

    private function norm(string $path): string
    {
        $path = '/' . ltrim($path, '/');
        $path = rtrim($path, '/');
        return $path === '' ? '/' : $path;
    }
}
