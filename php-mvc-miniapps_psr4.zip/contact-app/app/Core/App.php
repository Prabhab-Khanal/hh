<?php
declare(strict_types=1);

namespace App\Core;

final class App
{
    private Router $router;

    public function __construct()
    {
        $this->router = new Router();
        require __DIR__ . '/../routes.php';
    }

    public function run(): void
    {
        $path = $_GET['path'] ?? '/';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $this->router->dispatch($method, $path);
    }

    public function router(): Router
    {
        return $this->router;
    }
}
