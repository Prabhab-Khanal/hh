<?php
$ctl = new \App\Controllers\CsvController();
$this->router()->get('/', fn() => $ctl->form());
$this->router()->post('/upload', fn() => $ctl->upload());
$this->router()->get('/preview', fn() => $ctl->preview());
