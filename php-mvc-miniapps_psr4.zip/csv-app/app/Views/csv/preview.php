<h1>preview</h1>
<p>batch: <?= htmlspecialchars($batch) ?> | rows: <?= (int)$count ?></p>
<p><a href="/">back</a></p>

<table border="1" cellpadding="4">
<tr><th>#</th><th>col1</th><th>col2</th><th>col3</th></tr>
<?php foreach ($rows as $r): ?>
<tr>
  <td><?= (int)$r['row_index'] ?></td>
  <td><?= htmlspecialchars((string)($r['col1'] ?? '')) ?></td>
  <td><?= htmlspecialchars((string)($r['col2'] ?? '')) ?></td>
  <td><?= htmlspecialchars((string)($r['col3'] ?? '')) ?></td>
</tr>
<?php endforeach; ?>
</table>
