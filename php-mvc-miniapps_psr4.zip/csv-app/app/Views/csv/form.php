<h1>csv upload</h1>
<form method="post" action="/upload" enctype="multipart/form-data">
  <input type="file" name="csv" accept=".csv">
  <button type="submit">upload</button>
</form>
<p>redirects to /preview?batch=...</p>
