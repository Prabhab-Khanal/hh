<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\CsvRows;

final class CsvController extends Controller
{
    public function form(): void { $this->view('csv/form', ['title'=>'csv']); }

    public function upload(): void
    {
        if (!isset($_FILES['csv']) || $_FILES['csv']['error'] !== UPLOAD_ERR_OK) { echo "<p>no file</p><a href='/'>back</a>"; return; }
        $name = (string)$_FILES['csv']['name'];
        $tmp  = (string)$_FILES['csv']['tmp_name'];
        if (!preg_match('/\.csv$/i', $name)) { echo "<p>only csv</p><a href='/'>back</a>"; return; }

        $batch = bin2hex(random_bytes(8));
        $count = (new CsvRows())->import($tmp, $batch);
        $this->redirect('/preview?batch=' . urlencode($batch) . '&count=' . $count);
    }

    public function preview(): void
    {
        $batch = (string)($_GET['batch'] ?? '');
        $rows = $batch ? (new CsvRows())->rows($batch) : [];
        $count = (int)($_GET['count'] ?? 0);
        $this->view('csv/preview', ['title'=>'preview','batch'=>$batch,'rows'=>$rows,'count'=>$count]);
    }
}
