<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class CsvRows
{
    public function import(string $tmp, string $batch): int
    {
        $fh = fopen($tmp, 'r');
        if ($fh === false) return 0;

        $st = Database::pdo()->prepare("INSERT INTO csv_rows (batch_id,row_index,col1,col2,col3) VALUES (:b,:i,:c1,:c2,:c3)");
        $i=0;
        while (($row = fgetcsv($fh)) !== false) {
            $st->execute(['b'=>$batch,'i'=>$i,'c1'=>$row[0]??null,'c2'=>$row[1]??null,'c3'=>$row[2]??null]);
            $i++;
        }
        fclose($fh);
        return $i;
    }

    public function rows(string $batch): array
    {
        $st = Database::pdo()->prepare("SELECT row_index,col1,col2,col3 FROM csv_rows WHERE batch_id=:b ORDER BY row_index ASC");
        $st->execute(['b'=>$batch]);
        return $st->fetchAll();
    }
}
