Run:
- docker compose run --rm php composer install
- docker compose up --build
Open http://localhost:8081

You must insert a user with password_hash in `users` table.
