<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class User
{
    public function findByEmail(string $email): ?array
    {
        $st = Database::pdo()->prepare("SELECT id,email,password_hash FROM users WHERE email=:e LIMIT 1");
        $st->execute(['e'=>$email]);
        $r = $st->fetch();
        return $r ?: null;
    }
}
