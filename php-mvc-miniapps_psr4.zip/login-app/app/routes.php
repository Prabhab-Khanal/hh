<?php
$ctl = new \App\Controllers\LoginController();
$this->router()->get('/', fn() => $ctl->form());
$this->router()->post('/login', fn() => $ctl->login());
