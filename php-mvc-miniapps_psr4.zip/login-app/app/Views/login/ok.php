<h1>ok</h1>
<p>logged in (only this request): <?= htmlspecialchars($email) ?></p>
<p><a href="/">back</a></p>
