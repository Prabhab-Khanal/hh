<h1>login</h1>
<form method="post" action="/login">
  <p><input name="email" placeholder="email"></p>
  <p><input name="password" type="password" placeholder="password"></p>
  <button type="submit">go</button>
</form>
<p>no sessions. doesn't keep you logged in.</p>
