<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;

final class LoginController extends Controller
{
    public function form(): void { $this->view('login/form', ['title'=>'login']); }

    public function login(): void
    {
        $e = trim((string)($_POST['email'] ?? ''));
        $p = (string)($_POST['password'] ?? '');
        $u = (new User())->findByEmail($e);

        if ($u && password_verify($p, (string)$u['password_hash'])) {
            $this->view('login/ok', ['title'=>'ok','email'=>$e]);
            return;
        }
        echo "<p>wrong</p><a href='/'>back</a>";
    }
}
