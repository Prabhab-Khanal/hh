<?php
$ctl = new \App\Controllers\TodoController();
$this->router()->get('/', fn() => $ctl->index());
$this->router()->post('/create', fn() => $ctl->create());
$this->router()->post('/toggle', fn() => $ctl->toggle());
$this->router()->post('/delete', fn() => $ctl->delete());
