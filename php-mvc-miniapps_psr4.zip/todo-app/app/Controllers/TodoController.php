<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Todo;

final class TodoController extends Controller
{
    public function index(): void
    {
        $todos = (new Todo())->all();
        $this->view('todo/index', ['title' => 'todo', 'todos' => $todos]);
    }

    public function create(): void
    {
        $t = trim((string)($_POST['title'] ?? ''));
        if ($t !== '') (new Todo())->create($t);
        $this->redirect('/');
    }

    public function toggle(): void
    {
        (new Todo())->toggle((int)($_POST['id'] ?? 0));
        $this->redirect('/');
    }

    public function delete(): void
    {
        (new Todo())->delete((int)($_POST['id'] ?? 0));
        $this->redirect('/');
    }
}
