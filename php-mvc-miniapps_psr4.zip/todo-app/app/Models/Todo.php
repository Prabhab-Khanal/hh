<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Todo
{
    public function all(): array
    {
        return Database::pdo()->query("SELECT id,title,is_done,created_at FROM todos ORDER BY id DESC")->fetchAll();
    }

    public function create(string $title): void
    {
        $st = Database::pdo()->prepare("INSERT INTO todos (title) VALUES (:t)");
        $st->execute(['t' => $title]);
    }

    public function toggle(int $id): void
    {
        $st = Database::pdo()->prepare("UPDATE todos SET is_done=1-is_done WHERE id=:id");
        $st->execute(['id' => $id]);
    }

    public function delete(int $id): void
    {
        $st = Database::pdo()->prepare("DELETE FROM todos WHERE id=:id");
        $st->execute(['id' => $id]);
    }
}
