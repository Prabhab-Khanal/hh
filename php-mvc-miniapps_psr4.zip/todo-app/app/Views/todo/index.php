<h1>todo</h1>
<form method="post" action="/create">
  <input name="title" placeholder="task">
  <button type="submit">add</button>
</form>

<ul>
<?php foreach ($todos as $t): ?>
  <li>
    <?php if ((int)$t['is_done'] === 1): ?><s><?= htmlspecialchars($t['title']) ?></s>
    <?php else: ?><?= htmlspecialchars($t['title']) ?><?php endif; ?>

    <form method="post" action="/toggle" style="display:inline">
      <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
      <button type="submit">toggle</button>
    </form>

    <form method="post" action="/delete" style="display:inline">
      <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
      <button type="submit">del</button>
    </form>
  </li>
<?php endforeach; ?>
</ul>
